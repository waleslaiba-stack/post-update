# 🚀 Facebook Post & Link DIE Monitor Telegram Bot

A high-performance, asynchronous Python Telegram Bot built with **python-telegram-bot v20+**, **aiohttp**, and **aiosqlite** designed to monitor Facebook posts and links 24/7. It alerts you the instant a monitored post is deleted, removed by Facebook, or becomes inaccessible (**DIE**).

Engineered for seamless one-click deployment as a background worker on **Railway** hosting.

---

## 📋 Features

- 🔗 **Multi-Link Ingestion**: Paste single or multiple Facebook URLs in one message separated by spaces or newlines.
- 🆔 **Smart UID Extraction**: Automatically parses Post IDs, Page UIDs, Reels, Watch, and Group permalinks with fallback hashing.
- ⚡ **Asynchronous Background Engine**: Non-blocking scanning loop checking active links every 60–120 seconds with configurable rate-limit pacing.
- 🛡️ **Sophisticated "DIE" Detection**: Inspects HTTP status codes, redirects to login/checkpoint, and identifies Facebook removal notices across multiple languages.
- 🔔 **Strict Message Formatting**:
  - **First Message**: Immediate active confirmation card with hyperlinked URL, extracted title, timestamp, and action buttons.
  - **Second Message**: Autonomous DEAD alert triggered upon deletion, displaying processing time, hide/show info toggling, and continuation controls.
- 📱 **/setcommands Compatible**: Pre-configured menu with `/start`, `/add`, `/list`, `/remove`, `/tools`, and `/cancel`.
- 🗄️ **Persistent Storage**: Non-blocking SQLite storage via `aiosqlite`.

---

## 📂 Project Structure

```
├── bot.py              # Main asynchronous bot application & command/callback handlers
├── checker.py          # Facebook HTTP accessibility & content inspection engine
├── database.py         # Async SQLite database interface (aiosqlite)
├── requirements.txt    # Production dependencies
├── Procfile            # Worker process definition for Railway
├── railway.json        # Railway deployment configuration
├── runtime.txt         # Python runtime version
└── .env.example        # Environment variables configuration template
```

---

## 💬 Message Layouts

### 1. Active Confirmation Card (When Added)
```text
🔔 UID: 100084729104829 - Link Facebook
🟢 Status: ACTIVE ✅
👤 Name: Example Page Post
📝 Note: None
⏱️ Created Time: 14:30:15 09-09-2026
🔄 Progress: Monitoring, waiting for DIE ❌
```
*Inline Action Buttons:*
`[ ✏️ Edit ] [ 📋 List ]`
`[ 🏠 Main Menu ]`

### 2. Dead Alert (When Removed / DIE)
```text
🔔 UID: 100084729104829
🔴 Status: DEAD ❌
👤 Name: Example Page Post
📝 Note: None
⏱️ Created: 09-09-2026 14:30:15
⏰ Updated: 09-09-2026 14:42:30
⏳ Processing Time: 12 minutes 15 seconds
```
*Inline Action Buttons:*
`[ 🙈 Hide Info ] [ 🐵 Show Info ]`
`[ 🟢 Continue Monitoring ] [ 🔴 Stop Monitoring ]`

---

## 🛠️ Step-by-Step GitHub to Railway Deployment Guide

### Step 1: Create your Telegram Bot Token
1. Open Telegram and search for [@BotFather](https://t.me/BotFather).
2. Send `/newbot` and follow the prompts to choose a name and username (e.g., `MyFBMonitorBot`).
3. Copy the generated **HTTP API Token** (e.g., `7123456789:AAFnB_x...`).
4. (Optional) In BotFather, send `/setcommands` to configure the menu:
   ```text
   start - 🚀 Start Dashboard
   add - ➕ Add New Link to Monitor
   list - 📋 List of Added Links
   remove - 🗑️ Remove Added Link
   tools - 🛠️ Utilities / Tools
   cancel - ❌ Cancel Current Action
   ```

---

### Step 2: Push the Code to GitHub
1. Initialize a Git repository on your machine:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of Facebook Link Monitor Bot"
   ```
2. Create a new repository on [GitHub](https://github.com/new) (e.g. `facebook-monitor-bot`).
3. Push your repository:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/facebook-monitor-bot.git
   git branch -M main
   git push -u origin main
   ```

---

### Step 3: Deploy on Railway
1. Log in to [Railway.app](https://railway.app/).
2. Click **"+ New Project"** and select **"Deploy from GitHub repo"**.
3. Choose your `facebook-monitor-bot` repository.
4. Click **"Deploy Now"**.

---

### Step 4: Configure Environment Variables in Railway
1. Go to your newly created project on the Railway dashboard.
2. Click on the service box and navigate to the **"Variables"** tab.
3. Click **"New Variable"** (or "Raw Editor") and set:
   ```env
   BOT_TOKEN=7123456789:AAFnB_xXXXXXXXXXXXXX-YYYYYYYYYY
   CHECK_INTERVAL_SECONDS=60
   REQUEST_DELAY_SECONDS=2.0
   DATABASE_PATH=monitor.db
   ```
   *(Optional)* If you want to restrict the bot to your Telegram account only, add:
   ```env
   ALLOWED_USER_IDS=123456789
   ```
   *(You can find your user ID by messaging [@userinfobot](https://t.me/userinfobot) on Telegram).*

---

### Step 5: (Recommended) Attach a Persistent Volume on Railway
Railway dynos/containers use an ephemeral file system by default. To retain your monitored links database across redeploys:
1. In the Railway service dashboard, click **"Volumes"** tab (or right-click canvas -> **"Add Volume"**).
2. Mount the volume path to: `/data`
3. Update the `DATABASE_PATH` variable in the **"Variables"** tab to:
   ```env
   DATABASE_PATH=/data/monitor.db
   ```
4. Click **Deploy / Redeploy**.

---

### Step 6: Verify Deployment
1. Check the **"Deployments"** -> **"View Logs"** tab on Railway.
2. You will see:
   ```text
   INFO:FBMonitorBot:Database initialized at /data/monitor.db
   INFO:FBMonitorBot:Successfully registered Telegram bot menu commands
   INFO:FBMonitorBot:Background monitoring worker started. Interval: 60s
   INFO:FBMonitorBot:Bot started successfully. Listening for updates...
   ```
3. Open Telegram and send `/start` to your bot! 🎉

---

## 💻 Local Testing & Development

```bash
# 1. Clone repository
git clone https://github.com/YOUR_USERNAME/facebook-monitor-bot.git
cd facebook-monitor-bot

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Copy and edit environment variables
cp .env.example .env
# Open .env and insert your BOT_TOKEN

# 5. Start the bot
python bot.py
```

---

## ⚙️ Configuration Reference

| Variable | Default | Description |
| :--- | :--- | :--- |
| `BOT_TOKEN` | *Required* | Telegram Bot token from @BotFather |
| `CHECK_INTERVAL_SECONDS` | `60` | Delay between consecutive scan passes |
| `REQUEST_DELAY_SECONDS` | `2.0` | Pacing delay between checks to prevent Facebook blocks |
| `MAX_CONCURRENT_CHECKS` | `5` | Maximum concurrent async HTTP requests |
| `DATABASE_PATH` | `monitor.db` | Location of SQLite storage database |
| `ALLOWED_USER_IDS` | `""` (Open) | Comma-separated list of allowed Telegram user IDs |
| `USER_AGENT` | *Realistic Chrome* | Custom browser User-Agent header |
