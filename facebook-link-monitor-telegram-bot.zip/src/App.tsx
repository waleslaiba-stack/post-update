import React, { useState } from 'react';
import {
  MessageSquare,
  FileCode2,
  Rocket,
  Search,
  Download,
  Github,
  CheckCircle2,
  Radio,
  BellRing,
  ExternalLink,
  ShieldCheck,
  Zap
} from 'lucide-react';
import { TelegramSimulator } from './components/TelegramSimulator';
import { FileBrowser } from './components/FileBrowser';
import { LinkTester } from './components/LinkTester';
import { DeploymentGuide } from './components/DeploymentGuide';
import { MonitoredLink } from './types';
import { PROJECT_FILES } from './data/projectFiles';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'tester' | 'files' | 'deploy'>('simulator');

  // Initial demo links matching requirement specs
  const [monitoredLinks, setMonitoredLinks] = useState<MonitoredLink[]>([
    {
      id: 101,
      uid: '100084729104829',
      url: 'https://www.facebook.com/100084729104829/posts/pfbid02xXyZ9810',
      name: 'Official Campaign Announcement',
      note: 'None',
      status: 'ACTIVE',
      createdAt: '09-09-2026 14:30:15',
      updatedAt: '09-09-2026 14:30:15',
      isDeadAlertSent: false,
      isHidden: false,
    },
    {
      id: 102,
      uid: '7829104819204',
      url: 'https://fb.watch/qX8_yZ0918/',
      name: 'Facebook Watch Video Stream',
      note: 'Monitored client media',
      status: 'ACTIVE',
      createdAt: '09-09-2026 15:10:00',
      updatedAt: '09-09-2026 15:10:00',
      isDeadAlertSent: false,
      isHidden: false,
    }
  ]);

  const downloadAllFiles = () => {
    // Generate an all-in-one shell export script or download instructions
    const combinedScript = PROJECT_FILES.map(
      (f) => `### --- ${f.name} ---\n${f.content}\n`
    ).join('\n\n');

    const blob = new Blob([combinedScript], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'facebook-monitor-telegram-bot-files.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white">
      {/* Top Main Navigation Header */}
      <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-sky-500/20">
              <BellRing className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-sm sm:text-base text-white tracking-tight">
                  Facebook Link Monitor
                </h1>
                <span className="bg-emerald-500/10 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Railway Worker
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Asynchronous Python Telegram Bot (python-telegram-bot v20+ • aiosqlite • aiohttp)
              </p>
            </div>
          </div>

          {/* Center Tabs */}
          <div className="flex items-center bg-slate-900 border border-slate-800 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                activeTab === 'simulator'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Bot Simulator</span>
            </button>

            <button
              onClick={() => setActiveTab('tester')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                activeTab === 'tester'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Search className="w-3.5 h-3.5" />
              <span>DIE Tester</span>
            </button>

            <button
              onClick={() => setActiveTab('files')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                activeTab === 'files'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5" />
              <span>Code Files</span>
            </button>

            <button
              onClick={() => setActiveTab('deploy')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                activeTab === 'deploy'
                  ? 'bg-sky-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Rocket className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Railway</span> Guide
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={downloadAllFiles}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer border border-slate-700/60 shadow-sm"
              title="Export all Python and Railway configuration files"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden lg:inline">Export Files</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col">
        {activeTab === 'simulator' && (
          <div className="flex-1 flex flex-col gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-900/60 border border-slate-800 px-4 py-3 rounded-xl text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="font-semibold text-white">Interactive Telegram Bot Sandbox:</span>
                <span className="text-slate-400">
                  Tests exact message formats (Active & Dead Alert cards), multi-link pasting, and button callbacks.
                </span>
              </div>
              <div className="flex items-center gap-2 text-slate-400 text-[11px]">
                <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  Active Links: {monitoredLinks.filter((l) => l.status === 'ACTIVE').length}
                </span>
                <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                  Dead Detections: {monitoredLinks.filter((l) => l.status === 'DEAD').length}
                </span>
              </div>
            </div>

            <div className="flex-1 min-h-[620px]">
              <TelegramSimulator
                monitoredLinks={monitoredLinks}
                setMonitoredLinks={setMonitoredLinks}
              />
            </div>
          </div>
        )}

        {activeTab === 'tester' && (
          <div className="flex-1">
            <LinkTester
              onAddDirectly={(url) => {
                setActiveTab('simulator');
              }}
            />
          </div>
        )}

        {activeTab === 'files' && (
          <div className="flex-1 min-h-[640px]">
            <FileBrowser />
          </div>
        )}

        {activeTab === 'deploy' && (
          <div className="flex-1">
            <DeploymentGuide />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Facebook Link DIE Monitor • Production-ready Telegram Bot for Railway Worker</span>
          <div className="flex items-center gap-4 text-slate-400 text-[11px]">
            <span>python-telegram-bot v20+</span>
            <span>•</span>
            <span>aiosqlite</span>
            <span>•</span>
            <span>aiohttp</span>
            <span>•</span>
            <span>Nixpacks / Procfile</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
