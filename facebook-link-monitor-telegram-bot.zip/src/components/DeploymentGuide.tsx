import React, { useState } from 'react';
import {
  CheckCircle,
  Copy,
  Check,
  ExternalLink,
  Terminal,
  Shield,
  HardDrive,
  Rocket,
  Key,
  HelpCircle,
  Server
} from 'lucide-react';

export function DeploymentGuide() {
  const [copiedIndex, setCopiedIndex] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(id);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const gitSnippet = `# 1. Initialize and commit repository
git init
git add .
git commit -m "feat: production Facebook monitor bot for Railway"

# 2. Add your GitHub remote repository
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/fb-link-monitor-bot.git
git branch -M main

# 3. Push to GitHub
git push -u origin main`;

  const envSnippet = `BOT_TOKEN=7123456789:AAFnB_xXXXXXXXXXXXXX-YYYYYYYYYY
CHECK_INTERVAL_SECONDS=60
REQUEST_DELAY_SECONDS=2.0
DATABASE_PATH=monitor.db`;

  const volumeEnvSnippet = `DATABASE_PATH=/data/monitor.db`;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-2xl space-y-8">
      <div>
        <div className="flex items-center gap-2 mb-1.5">
          <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Rocket className="w-4 h-4" />
          </span>
          <h2 className="text-white font-semibold text-base sm:text-lg">
            Production Deployment Guide: GitHub ➔ Railway Worker
          </h2>
        </div>
        <p className="text-xs sm:text-sm text-slate-400">
          Follow these 5 streamlined steps to deploy this bot 24/7 as an uninterrupted background worker on Railway.
        </p>
      </div>

      {/* Step 1 */}
      <div className="border border-slate-800 rounded-xl p-4 sm:p-5 bg-slate-950/60 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-bold text-xs">
              1
            </span>
            <h3 className="text-slate-100 font-semibold text-sm">
              Create Telegram Bot Token with @BotFather
            </h3>
          </div>
          <a
            href="https://t.me/BotFather"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300"
          >
            <span>Open @BotFather</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          Open Telegram, send <code>/newbot</code> to <b>@BotFather</b>, name your bot, and copy your API Token (e.g. <code>7123456789:AAFnB_x...</code>).
        </p>
        <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 text-xs text-slate-400 space-y-1 font-mono">
          <div className="text-slate-500 text-[11px] font-sans font-semibold">Optional menu setup with /setcommands:</div>
          <div>start - 🚀 Start Dashboard</div>
          <div>add - ➕ Add New Link to Monitor</div>
          <div>list - 📋 List of Added Links</div>
          <div>remove - 🗑️ Remove Added Link</div>
          <div>tools - 🛠️ Utilities / Tools</div>
          <div>cancel - ❌ Cancel Current Action</div>
        </div>
      </div>

      {/* Step 2 */}
      <div className="border border-slate-800 rounded-xl p-4 sm:p-5 bg-slate-950/60 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-bold text-xs">
              2
            </span>
            <h3 className="text-slate-100 font-semibold text-sm">
              Push Repository to GitHub
            </h3>
          </div>
          <button
            onClick={() => copyToClipboard(gitSnippet, 'git')}
            className="flex items-center gap-1 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded border border-slate-700 transition cursor-pointer"
          >
            {copiedIndex === 'git' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedIndex === 'git' ? 'Copied' : 'Copy Commands'}</span>
          </button>
        </div>
        <pre className="bg-slate-900 text-slate-200 text-xs font-mono p-3 rounded-lg border border-slate-800 overflow-x-auto select-all">
          {gitSnippet}
        </pre>
      </div>

      {/* Step 3 */}
      <div className="border border-slate-800 rounded-xl p-4 sm:p-5 bg-slate-950/60 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-bold text-xs">
              3
            </span>
            <h3 className="text-slate-100 font-semibold text-sm">
              Deploy on Railway as Background Worker
            </h3>
          </div>
          <a
            href="https://railway.app/new"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 text-xs text-sky-400 hover:text-sky-300"
          >
            <span>Open Railway.app</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          1. On <a href="https://railway.app" target="_blank" rel="noopener noreferrer" className="text-sky-400 underline">Railway</a>, click <b>"+ New Project"</b> ➔ <b>"Deploy from GitHub repo"</b>.<br />
          2. Select your newly pushed repository. Railway will detect the <code>Procfile</code> (<code>worker: python bot.py</code>) and <code>requirements.txt</code> automatically using Nixpacks.
        </p>
      </div>

      {/* Step 4 */}
      <div className="border border-slate-800 rounded-xl p-4 sm:p-5 bg-slate-950/60 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-bold text-xs">
              4
            </span>
            <h3 className="text-slate-100 font-semibold text-sm">
              Set Environment Variables on Railway
            </h3>
          </div>
          <button
            onClick={() => copyToClipboard(envSnippet, 'env')}
            className="flex items-center gap-1 text-xs text-slate-300 bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded border border-slate-700 transition cursor-pointer"
          >
            {copiedIndex === 'env' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedIndex === 'env' ? 'Copied' : 'Copy Variables'}</span>
          </button>
        </div>
        <p className="text-xs text-slate-300">
          In your Railway project service, go to the <b>"Variables"</b> tab (Raw Editor) and paste:
        </p>
        <pre className="bg-slate-900 text-slate-200 text-xs font-mono p-3 rounded-lg border border-slate-800 overflow-x-auto select-all">
          {envSnippet}
        </pre>
      </div>

      {/* Step 5 */}
      <div className="border border-emerald-900/40 rounded-xl p-4 sm:p-5 bg-emerald-950/10 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold text-xs">
              5
            </span>
            <h3 className="text-emerald-200 font-semibold text-sm flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" />
              <span>Recommended: Attach Persistent Volume for SQLite</span>
            </h3>
          </div>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          Railway containers use an ephemeral filesystem. To ensure your monitored links and stats survive server restarts:
        </p>
        <ul className="text-xs text-slate-300 list-disc list-inside space-y-1">
          <li>Click the <b>"Volumes"</b> tab on Railway (or right-click canvas ➔ <b>Add Volume</b>).</li>
          <li>Set Mount Path to: <code className="bg-slate-800 px-1.5 py-0.5 rounded text-sky-300">/data</code></li>
          <li>Update your variable in Railway: <code className="bg-slate-800 px-1.5 py-0.5 rounded text-emerald-300">DATABASE_PATH=/data/monitor.db</code></li>
        </ul>
      </div>

      {/* Step 6 */}
      <div className="border border-slate-800 rounded-xl p-4 sm:p-5 bg-slate-950/60 space-y-3">
        <div className="flex items-center gap-3">
          <span className="w-7 h-7 rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30 flex items-center justify-center font-bold text-xs">
            6
          </span>
          <h3 className="text-slate-100 font-semibold text-sm">
            Verify Live Worker Logs
          </h3>
        </div>
        <p className="text-xs text-slate-300">
          Check the <b>"View Logs"</b> tab in Railway. Once deployed, you will observe:
        </p>
        <pre className="bg-slate-900 text-emerald-400 text-xs font-mono p-3 rounded-lg border border-slate-800 overflow-x-auto">
{`INFO:FBMonitorBot:Database initialized at /data/monitor.db
INFO:FBMonitorBot:Successfully registered Telegram bot menu commands
INFO:FBMonitorBot:Background monitoring worker started. Interval: 60s
INFO:FBMonitorBot:Bot started successfully. Listening for updates...`}
        </pre>
      </div>
    </div>
  );
}
