import React, { useState } from 'react';
import {
  FileCode,
  Copy,
  Check,
  Download,
  Terminal,
  ExternalLink,
  Layers,
  FileText,
  FileSpreadsheet,
  Cpu
} from 'lucide-react';
import { PROJECT_FILES } from '../data/projectFiles';
import { FileItem } from '../types';

export function FileBrowser() {
  const [selectedFile, setSelectedFile] = useState<FileItem>(PROJECT_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (file: FileItem) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const getFileIcon = (fileName: string) => {
    if (fileName.endsWith('.py')) return <FileCode className="w-4 h-4 text-emerald-400" />;
    if (fileName.endsWith('.txt')) return <FileText className="w-4 h-4 text-amber-400" />;
    if (fileName.endsWith('.json')) return <Cpu className="w-4 h-4 text-sky-400" />;
    if (fileName === 'Procfile') return <Terminal className="w-4 h-4 text-purple-400" />;
    return <FileText className="w-4 h-4 text-slate-400" />;
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden flex flex-col h-full shadow-2xl">
      {/* File Browser Top Nav */}
      <div className="bg-slate-950 border-b border-slate-800 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto max-w-full pb-1 sm:pb-0 no-scrollbar">
          {PROJECT_FILES.map((file) => {
            const isActive = selectedFile.name === file.name;
            return (
              <button
                key={file.name}
                onClick={() => setSelectedFile(file)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-mono transition cursor-pointer shrink-0 border ${
                  isActive
                    ? 'bg-slate-800 text-sky-400 border-sky-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border-transparent'
                }`}
              >
                {getFileIcon(file.name)}
                <span>{file.name}</span>
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer border border-slate-700/60"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Code'}</span>
          </button>
          <button
            onClick={() => handleDownload(selectedFile)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-medium transition cursor-pointer shadow-sm"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Download</span>
          </button>
        </div>
      </div>

      {/* File Description Header */}
      <div className="bg-slate-950/60 px-5 py-2.5 border-b border-slate-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-slate-300">
          <span className="font-semibold text-slate-200 font-mono">{selectedFile.name}</span>
          <span className="text-slate-600">•</span>
          <span className="text-slate-400 text-[11px] truncate max-w-md">{selectedFile.description}</span>
        </div>
        <span className="px-2 py-0.5 rounded text-[10px] uppercase font-mono tracking-wider bg-slate-800 text-slate-400 border border-slate-700">
          {selectedFile.language}
        </span>
      </div>

      {/* Code Editor Window */}
      <div className="flex-1 overflow-auto bg-slate-950 font-mono text-xs p-4 leading-relaxed select-text">
        <div className="flex">
          {/* Line Numbers */}
          <div className="pr-4 text-slate-600 select-none text-right font-mono text-xs border-r border-slate-800/80 mr-4">
            {selectedFile.content.split('\n').map((_, idx) => (
              <div key={idx}>{idx + 1}</div>
            ))}
          </div>
          {/* Code Body */}
          <pre className="text-slate-200 whitespace-pre overflow-x-auto flex-1 font-mono text-[13px]">
            {selectedFile.content}
          </pre>
        </div>
      </div>
    </div>
  );
}
