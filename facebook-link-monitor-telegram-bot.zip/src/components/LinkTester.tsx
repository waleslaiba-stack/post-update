import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  Copy,
  ExternalLink,
  ShieldAlert,
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface LinkTesterProps {
  onAddDirectly?: (url: string) => void;
}

export function LinkTester({ onAddDirectly }: LinkTesterProps) {
  const [testUrl, setTestUrl] = useState(
    'https://www.facebook.com/100084729104829/posts/pfbid02xXyZ9810482'
  );
  const [isChecking, setIsChecking] = useState(false);
  const [checkResult, setCheckResult] = useState<any>(null);

  const presets = [
    {
      label: '🟢 Active Public Post',
      url: 'https://www.facebook.com/100084729104829/posts/pfbid02xXyZ9810482',
      scenario: 'active',
    },
    {
      label: '🔴 Deleted Post ("Content isn\'t available")',
      url: 'https://www.facebook.com/facebook/posts/404deletedpost999',
      scenario: 'dead_content',
    },
    {
      label: '🔴 Redirected to Login / Checkpoint',
      url: 'https://www.facebook.com/privategroup/posts/9912847192',
      scenario: 'dead_redirect',
    },
    {
      label: '🎬 FB Reel Video Link',
      url: 'https://www.facebook.com/reel/10847291829472',
      scenario: 'active_reel',
    },
    {
      label: '📺 fb.watch Short Link',
      url: 'https://fb.watch/qX8_yZ0918/',
      scenario: 'active_watch',
    },
  ];

  const runTest = (scenario?: string, overrideUrl?: string) => {
    const target = overrideUrl || testUrl;
    setIsChecking(true);

    setTimeout(() => {
      let uid = 'FB_' + Math.abs(target.split('').reduce((a, b) => ((a << 5) - a + b.charCodeAt(0)) | 0, 0)).toString(16).slice(0, 8);
      const postMatch = target.match(/\/posts\/(pfbid[0-9a-zA-Z]+|\d+)/);
      if (postMatch) uid = postMatch[1];
      const reelMatch = target.match(/\/reel\/(\d+)/);
      if (reelMatch) uid = reelMatch[1];
      const watchMatch = target.match(/(?:watch\/\?v=|fb\.watch\/)([0-9a-zA-Z_-]+)/);
      if (watchMatch) uid = watchMatch[1];

      let isAlive = true;
      let status = 'ACTIVE';
      let statusCode = 200;
      let reason = 'Page returned HTTP 200 OK with valid OpenGraph post metadata.';
      let detectedTitle = `Facebook Post (${uid})`;

      if (scenario === 'dead_content' || target.includes('deleted') || target.includes('404')) {
        isAlive = false;
        status = 'DEAD';
        statusCode = 404;
        reason = 'Matched removal signature: "This content isn\'t available right now" (Page Not Found)';
        detectedTitle = 'Content Not Found';
      } else if (scenario === 'dead_redirect' || target.includes('private')) {
        isAlive = false;
        status = 'DEAD';
        statusCode = 302;
        reason = 'Redirected to /login.php without retaining public context (Post removed or private)';
        detectedTitle = 'Facebook Login Required';
      } else if (target.includes('reel')) {
        detectedTitle = `Facebook Reel (${uid})`;
      } else if (target.includes('watch')) {
        detectedTitle = `Facebook Watch Video (${uid})`;
      }

      setCheckResult({
        url: target,
        uid,
        isAlive,
        status,
        statusCode,
        reason,
        detectedTitle,
        responseTimeMs: Math.floor(Math.random() * 200) + 150,
      });
      setIsChecking(false);
    }, 600);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 shadow-2xl flex flex-col gap-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="p-1.5 rounded-lg bg-sky-500/10 text-sky-400 border border-sky-500/20">
            <Search className="w-4 h-4" />
          </span>
          <h2 className="text-white font-semibold text-base">
            Facebook Link Inspector & DIE Heuristics Tester
          </h2>
        </div>
        <p className="text-xs text-slate-400">
          Test Facebook link UID extraction and simulated accessibility responses matching the <code>checker.py</code> detection pipeline.
        </p>
      </div>

      {/* Preset Scenarios */}
      <div>
        <label className="text-xs font-semibold text-slate-300 block mb-2">
          Test Preset Scenarios:
        </label>
        <div className="flex flex-wrap gap-2">
          {presets.map((preset) => (
            <button
              key={preset.label}
              onClick={() => {
                setTestUrl(preset.url);
                runTest(preset.scenario, preset.url);
              }}
              className="text-xs px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg border border-slate-700/80 transition cursor-pointer"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* URL Input */}
      <div className="flex flex-col sm:flex-row gap-2">
        <input
          type="text"
          value={testUrl}
          onChange={(e) => setTestUrl(e.target.value)}
          placeholder="https://www.facebook.com/.../posts/..."
          className="flex-1 bg-slate-950 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl px-4 py-2.5 text-sm font-mono text-slate-200 outline-none"
        />
        <button
          onClick={() => runTest()}
          disabled={isChecking || !testUrl.trim()}
          className="bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white px-5 py-2.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 transition cursor-pointer shrink-0 shadow-sm"
        >
          {isChecking ? (
            <span>Checking...</span>
          ) : (
            <>
              <Play className="w-4 h-4" />
              <span>Inspect Link</span>
            </>
          )}
        </button>
      </div>

      {/* Test Results Output */}
      {checkResult && (
        <div
          className={`border rounded-xl p-4 sm:p-5 transition ${
            checkResult.isAlive
              ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-100'
              : 'bg-rose-950/20 border-rose-500/30 text-rose-100'
          }`}
        >
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex items-center gap-2">
              {checkResult.isAlive ? (
                <div className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
              ) : (
                <div className="w-8 h-8 rounded-full bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-rose-400">
                  <XCircle className="w-5 h-5" />
                </div>
              )}
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm">
                    {checkResult.isAlive ? 'Status: ACTIVE ✅' : 'Status: DEAD ❌'}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded font-mono bg-slate-800 border border-slate-700 text-slate-300">
                    HTTP {checkResult.statusCode}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{checkResult.reason}</p>
              </div>
            </div>

            <span className="text-[11px] font-mono text-slate-400 bg-slate-900 px-2 py-1 rounded border border-slate-800">
              {checkResult.responseTimeMs}ms
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-950/80 p-3.5 rounded-lg border border-slate-800/80 font-mono">
            <div>
              <span className="text-slate-500 block">Extracted UID / ID:</span>
              <span className="text-sky-400 font-semibold select-all">{checkResult.uid}</span>
            </div>
            <div>
              <span className="text-slate-500 block">Detected Page / Post Title:</span>
              <span className="text-slate-200">{checkResult.detectedTitle}</span>
            </div>
            <div className="sm:col-span-2 break-all">
              <span className="text-slate-500 block">Target Canonical URL:</span>
              <span className="text-slate-300">{checkResult.url}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
