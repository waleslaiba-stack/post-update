import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Trash2,
  Play,
  RotateCcw,
  Zap,
  Info,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Radio,
  ExternalLink
} from 'lucide-react';
import { MonitoredLink, TelegramMessage } from '../types';

interface TelegramSimulatorProps {
  monitoredLinks: MonitoredLink[];
  setMonitoredLinks: React.Dispatch<React.SetStateAction<MonitoredLink[]>>;
}

export function TelegramSimulator({ monitoredLinks, setMonitoredLinks }: TelegramSimulatorProps) {
  const [messages, setMessages] = useState<TelegramMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [pendingAction, setPendingAction] = useState<{ action: string; linkId?: number } | null>(null);
  const [isSimulatingCheck, setIsSimulatingCheck] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Initial welcome message on first load
  useEffect(() => {
    if (messages.length === 0) {
      handleCommand('/start', false);
    }
  }, []);

  const formatNowTime = () => {
    const now = new Date();
    return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getExactNowStrings = () => {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const day = pad(now.getDate());
    const month = pad(now.getMonth() + 1);
    const year = now.getFullYear();
    const hours = pad(now.getHours());
    const minutes = pad(now.getMinutes());
    const seconds = pad(now.getSeconds());

    // First layout: <HH:MM:SS DD-MM-YYYY>
    const createdFirstFmt = `${hours}:${minutes}:${seconds} ${day}-${month}-${year}`;
    // Second layout: <DD-MM-YYYY HH:MM:SS>
    const standardFmt = `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;

    return { createdFirstFmt, standardFmt };
  };

  const addMessage = (msg: Omit<TelegramMessage, 'id' | 'timestamp'>) => {
    const newMsg: TelegramMessage = {
      ...msg,
      id: Math.random().toString(36).substring(7),
      timestamp: formatNowTime(),
    };
    setMessages((prev) => [...prev, newMsg]);
  };

  const handleCommand = (cmd: string, echoUser = true) => {
    if (echoUser) {
      addMessage({ sender: 'user', text: cmd });
    }

    if (cmd === '/start') {
      const activeCount = monitoredLinks.filter((l) => l.status === 'ACTIVE').length;
      const deadCount = monitoredLinks.filter((l) => l.status === 'DEAD').length;
      const stoppedCount = monitoredLinks.filter((l) => l.status === 'STOPPED').length;

      const text = `👋 Welcome to <b>Facebook Post & Link DIE Monitor Bot</b>!\n\nI monitor Facebook links in real-time and alert you immediately when a post is removed or becomes inaccessible.\n\n📊 <b>Your Dashboard:</b>\n• Total Monitored: <b>${monitoredLinks.length}</b>\n• 🟢 Active: <b>${activeCount}</b>\n• 🔴 Dead: <b>${deadCount}</b>\n• ⏸️ Stopped: <b>${stoppedCount}</b>\n\nPaste single or multiple Facebook links to start monitoring!`;

      addMessage({
        sender: 'bot',
        text,
        buttons: [
          [
            { text: '➕ Add Links', callbackData: 'cmd_add' },
            { text: '📋 List Links', callbackData: 'cmd_list' },
          ],
          [
            { text: '🛠️ Tools', callbackData: 'cmd_tools' },
            { text: '🔄 Refresh', callbackData: 'main_menu' },
          ],
        ],
      });
    } else if (cmd === '/add') {
      setPendingAction({ action: 'AWAITING_LINKS' });
      addMessage({
        sender: 'bot',
        text: `➕ <b>Add Links to Monitor</b>\n\nPlease paste one or multiple Facebook URLs in your next message (separated by line breaks or spaces).\n\n<i>Example:</i>\n<code>https://www.facebook.com/100084729104829/posts/pfbid02xXyZ\nhttps://fb.watch/qX8_yZ091/</code>\n\nSend /cancel to abort.`,
        buttons: [[{ text: '❌ Cancel', callbackData: 'cmd_cancel' }]],
      });
    } else if (cmd === '/list') {
      renderListMessage();
    } else if (cmd === '/remove') {
      addMessage({
        sender: 'bot',
        text: `🗑️ <b>Remove Link</b>\n\nSelect a link below or send <code>/remove &lt;UID&gt;</code>:`,
      });
      renderListMessage();
    } else if (cmd === '/tools') {
      const activeCount = monitoredLinks.filter((l) => l.status === 'ACTIVE').length;
      const deadCount = monitoredLinks.filter((l) => l.status === 'DEAD').length;
      addMessage({
        sender: 'bot',
        text: `🛠️ <b>Monitor Tools & Utilities:</b>\n\n⏱️ <b>Scan Interval:</b> 60–120 seconds\n🌐 <b>Rate Limit Delay:</b> 2.0s between requests\n💾 <b>Database:</b> aiosqlite\n📊 <b>Active Targets:</b> ${activeCount}\n🔴 <b>Dead Detections:</b> ${deadCount}`,
        buttons: [
          [
            { text: '⚡ Instant Check All', callbackData: 'tools_check_now' },
            { text: '🧹 Clear Dead Links', callbackData: 'tools_clean_dead' },
          ],
          [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
        ],
      });
    } else if (cmd === '/cancel') {
      setPendingAction(null);
      addMessage({
        sender: 'bot',
        text: `❌ Action cancelled. Ready for new commands.`,
      });
    }
  };

  const renderListMessage = () => {
    if (monitoredLinks.length === 0) {
      addMessage({
        sender: 'bot',
        text: `📋 <b>Monitored Links:</b>\n\nNo links are currently monitored. Click below to add your first Facebook link!`,
        buttons: [
          [{ text: '➕ Add New Link', callbackData: 'cmd_add' }],
          [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
        ],
      });
      return;
    }

    let text = `📋 <b>Monitored Links (${monitoredLinks.length} total):</b>\n\n`;
    const buttons: any[] = [];

    monitoredLinks.forEach((link) => {
      const icon = link.status === 'ACTIVE' ? '🟢' : link.status === 'DEAD' ? '🔴' : '⏸️';
      text += `${icon} <b>UID:</b> <code>${link.uid}</code>\n👤 <b>Name:</b> ${link.name}\n🔗 <a href="${link.url}">Link Facebook</a>\n----------------------------------------\n`;
      buttons.push([
        { text: `🔍 ${link.uid}`, callbackData: `view_${link.id}` },
        { text: '🗑️ Remove', callbackData: `remove_${link.id}` },
      ]);
    });

    buttons.push([
      { text: '➕ Add More', callbackData: 'cmd_add' },
      { text: '🏠 Main Menu', callbackData: 'main_menu' },
    ]);

    addMessage({
      sender: 'bot',
      text,
      buttons,
    });
  };

  // Extract UID logic identical to python checker.py
  const parseFbUid = (url: string): string => {
    try {
      const u = new URL(url);
      const sp = u.searchParams;
      for (const p of ['story_fbid', 'fbid', 'v', 'id']) {
        const val = sp.get(p);
        if (val && /^\d+$/.test(val)) return val;
      }
      const postMatch = url.match(/\/posts\/(pfbid[0-9a-zA-Z]+|\d+)/);
      if (postMatch) return postMatch[1];
      const watchMatch = url.match(/(?:watch\/\?v=|fb\.watch\/)([0-9a-zA-Z_-]+)/);
      if (watchMatch) return watchMatch[1];
      const reelMatch = url.match(/\/reel\/(\d+)/);
      if (reelMatch) return reelMatch[1];
      const groupsMatch = url.match(/\/groups\/[^/]+\/posts\/(\d+)/);
      if (groupsMatch) return groupsMatch[1];
    } catch {
      // ignore
    }
    // Fallback hash
    let hash = 0;
    for (let i = 0; i < url.length; i++) {
      hash = (hash << 5) - hash + url.charCodeAt(i);
      hash |= 0;
    }
    return 'FB_' + Math.abs(hash).toString(16).padStart(8, '0');
  };

  const processInputLinks = (text: string) => {
    // Check if user is editing a note
    if (pendingAction && pendingAction.action === 'EDIT_NOTE' && pendingAction.linkId) {
      const linkId = pendingAction.linkId;
      setPendingAction(null);
      setMonitoredLinks((prev) =>
        prev.map((l) => (l.id === linkId ? { ...l, note: text } : l))
      );
      const updated = monitoredLinks.find((l) => l.id === linkId);
      if (updated) {
        addMessage({
          sender: 'bot',
          text: `✅ Note updated successfully for UID: <code>${updated.uid}</code>\nNew note: <i>${text}</i>`,
          buttons: [
            [
              { text: '✏️ Edit Again', callbackData: `edit_${linkId}` },
              { text: '📋 List', callbackData: 'cmd_list' },
            ],
            [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
          ],
        });
      }
      return;
    }

    // Split by spaces or line breaks
    const tokens = text.split(/\s+/).map((t) => t.trim()).filter(Boolean);
    const fbUrls = tokens.filter(
      (t) =>
        t.includes('facebook.com') ||
        t.includes('fb.watch') ||
        t.includes('fb.me') ||
        t.startsWith('http://') ||
        t.startsWith('https://')
    );

    if (fbUrls.length === 0) {
      if (pendingAction?.action === 'AWAITING_LINKS') {
        addMessage({
          sender: 'bot',
          text: `⚠️ No valid Facebook links detected. Please send a link containing <code>facebook.com</code> or <code>fb.watch</code>, or /cancel.`,
        });
      } else {
        addMessage({
          sender: 'bot',
          text: `❓ Unrecognized input. Send /start for dashboard or /add to monitor a Facebook link.`,
        });
      }
      return;
    }

    setPendingAction(null);
    const { createdFirstFmt, standardFmt } = getExactNowStrings();

    fbUrls.forEach((url, idx) => {
      const cleanUrl = url.startsWith('http') ? url : `https://${url}`;
      const uid = parseFbUid(cleanUrl);
      const newId = Date.now() + idx;

      // Extract a plausible title/name
      let sampleName = 'Facebook Post';
      if (cleanUrl.includes('reel')) sampleName = 'Facebook Reel Video';
      else if (cleanUrl.includes('watch')) sampleName = 'Facebook Watch Video';
      else if (cleanUrl.includes('group')) sampleName = 'Group Community Post';
      else sampleName = `Official Update (${uid.slice(0, 8)})`;

      const newLink: MonitoredLink = {
        id: newId,
        uid,
        url: cleanUrl,
        name: sampleName,
        note: 'None',
        status: 'ACTIVE',
        createdAt: standardFmt,
        updatedAt: standardFmt,
        isDeadAlertSent: false,
        isHidden: false,
      };

      setMonitoredLinks((prev) => [newLink, ...prev.filter((l) => l.url !== cleanUrl)]);

      // Requirement 3: EXACT First Message Layout
      // 🔔 UID: <UID> - [Link Facebook](<URL>)
      // 🟢 Status: ACTIVE ✅
      // 👤 Name: <Name / Extracted Title>
      // 📝 Note: None
      // ⏱️ Created Time: <HH:MM:SS DD-MM-YYYY>
      // 🔄 Progress: Monitoring, waiting for DIE ❌
      const firstMsgText =
        `🔔 UID: ${uid} - <a href="${cleanUrl}">Link Facebook</a>\n` +
        `🟢 Status: ACTIVE ✅\n` +
        `👤 Name: ${sampleName}\n` +
        `📝 Note: None\n` +
        `⏱️ Created Time: ${createdFirstFmt}\n` +
        `🔄 Progress: Monitoring, waiting for DIE ❌`;

      addMessage({
        sender: 'bot',
        text: firstMsgText,
        linkId: newId,
        buttons: [
          [
            { text: '✏️ Edit', callbackData: `edit_${newId}` },
            { text: '📋 List', callbackData: 'cmd_list' },
          ],
          [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
        ],
      });
    });
  };

  const handleSend = () => {
    if (!inputValue.trim()) return;
    const text = inputValue.trim();
    setInputValue('');

    if (text.startsWith('/')) {
      handleCommand(text);
    } else {
      addMessage({ sender: 'user', text });
      processInputLinks(text);
    }
  };

  const handleButtonClick = (callbackData: string) => {
    if (callbackData === 'main_menu') {
      handleCommand('/start', false);
    } else if (callbackData === 'cmd_add') {
      handleCommand('/add', false);
    } else if (callbackData === 'cmd_list') {
      renderListMessage();
    } else if (callbackData === 'cmd_tools') {
      handleCommand('/tools', false);
    } else if (callbackData === 'cmd_cancel') {
      handleCommand('/cancel', false);
    } else if (callbackData === 'tools_check_now') {
      setIsSimulatingCheck(true);
      addMessage({
        sender: 'bot',
        text: `⚡ <b>Immediate Scan Started:</b> Checking ${monitoredLinks.length} target link(s) via aiohttp...`,
      });
      setTimeout(() => {
        setIsSimulatingCheck(false);
        addMessage({
          sender: 'bot',
          text: `✅ <b>Scan Complete:</b> All monitored links verified. No dead anomalies detected.`,
        });
      }, 1200);
    } else if (callbackData === 'tools_clean_dead') {
      const deadCount = monitoredLinks.filter((l) => l.status === 'DEAD').length;
      setMonitoredLinks((prev) => prev.filter((l) => l.status !== 'DEAD'));
      addMessage({
        sender: 'bot',
        text: `🧹 Cleaned ${deadCount} dead link(s) from monitoring database.`,
        buttons: [[{ text: '🏠 Main Menu', callbackData: 'main_menu' }]],
      });
    } else if (callbackData.startsWith('view_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      const link = monitoredLinks.find((l) => l.id === linkId);
      if (!link) return;

      if (link.status === 'DEAD') {
        triggerDeadAlert(link, link.isHidden);
      } else {
        const { createdFirstFmt } = getExactNowStrings();
        const activeText =
          `🔔 UID: ${link.uid} - <a href="${link.url}">Link Facebook</a>\n` +
          `🟢 Status: ACTIVE ✅\n` +
          `👤 Name: ${link.name}\n` +
          `📝 Note: ${link.note}\n` +
          `⏱️ Created Time: ${createdFirstFmt}\n` +
          `🔄 Progress: Monitoring, waiting for DIE ❌`;

        addMessage({
          sender: 'bot',
          text: activeText,
          linkId,
          buttons: [
            [
              { text: '✏️ Edit', callbackData: `edit_${linkId}` },
              { text: '📋 List', callbackData: 'cmd_list' },
            ],
            [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
          ],
        });
      }
    } else if (callbackData.startsWith('edit_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      const link = monitoredLinks.find((l) => l.id === linkId);
      if (!link) return;
      setPendingAction({ action: 'EDIT_NOTE', linkId });
      addMessage({
        sender: 'bot',
        text: `✏️ <b>Edit Note for UID:</b> <code>${link.uid}</code>\n\nCurrent Note: <i>${link.note}</i>\n\nPlease enter the new note text in your next message, or /cancel to abort.`,
        buttons: [[{ text: '❌ Cancel', callbackData: 'cmd_cancel' }]],
      });
    } else if (callbackData.startsWith('remove_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      const link = monitoredLinks.find((l) => l.id === linkId);
      setMonitoredLinks((prev) => prev.filter((l) => l.id !== linkId));
      addMessage({
        sender: 'bot',
        text: `🗑️ <b>Deleted:</b> UID <code>${link?.uid || linkId}</code> was removed from monitoring database.`,
        buttons: [
          [{ text: '📋 View Links', callbackData: 'cmd_list' }],
          [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
        ],
      });
    } else if (callbackData.startsWith('hide_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      setMonitoredLinks((prev) =>
        prev.map((l) => (l.id === linkId ? { ...l, isHidden: true } : l))
      );
      const link = monitoredLinks.find((l) => l.id === linkId);
      if (link) {
        triggerDeadAlert({ ...link, isHidden: true }, true);
      }
    } else if (callbackData.startsWith('show_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      setMonitoredLinks((prev) =>
        prev.map((l) => (l.id === linkId ? { ...l, isHidden: false } : l))
      );
      const link = monitoredLinks.find((l) => l.id === linkId);
      if (link) {
        triggerDeadAlert({ ...link, isHidden: false }, false);
      }
    } else if (callbackData.startsWith('continue_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      setMonitoredLinks((prev) =>
        prev.map((l) => (l.id === linkId ? { ...l, status: 'ACTIVE', isDeadAlertSent: false } : l))
      );
      const link = monitoredLinks.find((l) => l.id === linkId);
      addMessage({
        sender: 'bot',
        text: `🟢 <b>Monitoring Resumed:</b> UID <code>${link?.uid || linkId}</code> is marked ACTIVE again.`,
        buttons: [
          [{ text: '📋 List', callbackData: 'cmd_list' }],
          [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
        ],
      });
    } else if (callbackData.startsWith('stop_')) {
      const linkId = parseInt(callbackData.split('_')[1], 10);
      setMonitoredLinks((prev) =>
        prev.map((l) => (l.id === linkId ? { ...l, status: 'STOPPED' } : l))
      );
      const link = monitoredLinks.find((l) => l.id === linkId);
      addMessage({
        sender: 'bot',
        text: `🔴 <b>Monitoring Stopped:</b> UID <code>${link?.uid || linkId}</code> checks halted.`,
        buttons: [
          [
            { text: '🟢 Continue Monitoring', callbackData: `continue_${linkId}` },
            { text: '🗑️ Remove', callbackData: `remove_${linkId}` },
          ],
          [{ text: '🏠 Main Menu', callbackData: 'main_menu' }],
        ],
      });
    }
  };

  // Requirement 5: Autonomous Trigger for Second Message Layout (Deletion Notification / Dead Alert)
  const triggerDeadAlert = (targetLink: MonitoredLink, isHidden: boolean = false) => {
    const { standardFmt } = getExactNowStrings();
    const linkId = targetLink.id;

    // Format fields with hiding support
    const uidDisplay = isHidden ? '**********' : targetLink.uid;
    const nameDisplay = isHidden ? '**********' : targetLink.name;
    const noteDisplay = isHidden ? '**********' : targetLink.note;

    // Requirement 5: EXACT Second Message Layout:
    // 🔔 UID: <UID>
    // 🔴 Status: DEAD ❌
    // 👤 Name: <Name>
    // 📝 Note: None
    // ⏱️ Created: <DD-MM-YYYY HH:MM:SS>
    // ⏰ Updated: <DD-MM-YYYY HH:MM:SS>
    // ⏳ Processing Time: <X minutes Y seconds>
    const deadText =
      `🔔 UID: ${uidDisplay}\n` +
      `🔴 Status: DEAD ❌\n` +
      `👤 Name: ${nameDisplay}\n` +
      `📝 Note: ${noteDisplay}\n` +
      `⏱️ Created: ${targetLink.createdAt}\n` +
      `⏰ Updated: ${standardFmt}\n` +
      `⏳ Processing Time: 3 minutes 42 seconds`;

    addMessage({
      sender: 'bot',
      text: deadText,
      linkId,
      isDeadAlert: true,
      buttons: [
        [
          { text: '🙈 Hide Info', callbackData: `hide_${linkId}` },
          { text: '🐵 Show Info', callbackData: `show_${linkId}` },
        ],
        [
          { text: '🟢 Continue Monitoring', callbackData: `continue_${linkId}` },
          { text: '🔴 Stop Monitoring', callbackData: `stop_${linkId}` },
        ],
      ],
    });
  };

  const simulateDieEvent = () => {
    const activeLink = monitoredLinks.find((l) => l.status === 'ACTIVE') || monitoredLinks[0];
    if (!activeLink) {
      // Seed a default one if empty
      const { standardFmt } = getExactNowStrings();
      const mockLink: MonitoredLink = {
        id: Date.now(),
        uid: '100084729104829',
        url: 'https://www.facebook.com/100084729104829/posts/pfbid02xXyZ',
        name: 'Brand Promotion Post',
        note: 'Important campaign',
        status: 'DEAD',
        createdAt: standardFmt,
        updatedAt: standardFmt,
        isDeadAlertSent: true,
        isHidden: false,
      };
      setMonitoredLinks([mockLink]);
      triggerDeadAlert(mockLink, false);
      return;
    }

    setMonitoredLinks((prev) =>
      prev.map((l) =>
        l.id === activeLink.id ? { ...l, status: 'DEAD', isDeadAlertSent: true } : l
      )
    );

    triggerDeadAlert({ ...activeLink, status: 'DEAD' }, activeLink.isHidden);
  };

  const seedSampleLink = () => {
    processInputLinks(
      'https://www.facebook.com/100084729104829/posts/pfbid02xXyZ9810\nhttps://fb.watch/qX891024L/'
    );
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden">
      {/* Top Telegram Header */}
      <div className="bg-slate-950/90 backdrop-blur-md px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-sky-600 to-blue-500 flex items-center justify-center font-bold text-white shadow-md">
              FB
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-950 rounded-full animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-white font-semibold text-sm tracking-wide">
                Facebook Link DIE Monitor Bot
              </h2>
              <span className="bg-sky-500/20 text-sky-400 text-[10px] font-mono px-1.5 py-0.5 rounded border border-sky-500/30">
                BOT
              </span>
            </div>
            <p className="text-xs text-slate-400 flex items-center gap-1.5">
              <Radio className="w-3 h-3 text-emerald-400" />
              <span>Monitoring loop active (every 60s)</span>
            </p>
          </div>
        </div>

        {/* Quick action controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={simulateDieEvent}
            title="Simulate Facebook deleting a post to trigger the DIE alert"
            className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 text-xs font-medium rounded-lg border border-rose-500/30 transition shadow-sm active:scale-95 cursor-pointer"
          >
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">Simulate</span> DIE Alert
          </button>
          <button
            onClick={seedSampleLink}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-500/10 hover:bg-sky-500/20 text-sky-400 text-xs font-medium rounded-lg border border-sky-500/30 transition active:scale-95 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Add Sample Links</span>
          </button>
          <button
            onClick={() => setMessages([])}
            title="Clear Chat"
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Telegram Chat Message History */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-radial from-slate-900 via-slate-900 to-slate-950">
        <div className="flex justify-center">
          <span className="text-[11px] bg-slate-800/80 text-slate-400 px-3 py-1 rounded-full border border-slate-700/50 backdrop-blur-xs">
            Asynchronous Session Connected • PTB v20+
          </span>
        </div>

        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${
              msg.sender === 'user' ? 'items-end' : 'items-start'
            }`}
          >
            <div
              className={`max-w-[88%] sm:max-w-[75%] rounded-2xl px-4 py-3 shadow-lg relative ${
                msg.sender === 'user'
                  ? 'bg-sky-600 text-white rounded-br-xs'
                  : msg.isDeadAlert
                  ? 'bg-rose-950/40 text-rose-100 border border-rose-600/40 rounded-bl-xs'
                  : 'bg-slate-800/90 text-slate-100 border border-slate-700/60 rounded-bl-xs'
              }`}
            >
              {/* Message text formatted with preserved newlines & pre/code/links */}
              <div
                className="text-sm font-sans whitespace-pre-wrap leading-relaxed select-text font-mono text-[13px]"
                dangerouslySetInnerHTML={{
                  __html: msg.text.replace(
                    /<a href="([^"]+)">([^<]+)<\/a>/g,
                    '<a href="$1" target="_blank" rel="noopener noreferrer" class="text-sky-400 underline font-semibold hover:text-sky-300">$2 ↗</a>'
                  ),
                }}
              />

              <div className="flex items-center justify-end gap-1 mt-1 text-[10px] text-slate-400">
                <span>{msg.timestamp}</span>
                {msg.sender === 'user' && (
                  <CheckCircle2 className="w-3 h-3 text-sky-200 inline ml-0.5" />
                )}
              </div>
            </div>

            {/* Inline Action Buttons */}
            {msg.buttons && msg.buttons.length > 0 && (
              <div className="mt-1.5 space-y-1.5 w-full max-w-[88%] sm:max-w-[75%]">
                {msg.buttons.map((row, rIdx) => (
                  <div key={rIdx} className="grid grid-flow-col auto-cols-fr gap-1.5">
                    {row.map((btn, bIdx) => (
                      <button
                        key={bIdx}
                        onClick={() => handleButtonClick(btn.callbackData)}
                        className={`text-xs py-2 px-3 rounded-lg font-medium text-center transition flex items-center justify-center gap-1 cursor-pointer active:scale-98 ${
                          btn.text.includes('DIE') || btn.text.includes('Stop') || btn.text.includes('Remove')
                            ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30'
                            : btn.text.includes('Continue') || btn.text.includes('ACTIVE')
                            ? 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30'
                            : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700/80'
                        }`}
                      >
                        {btn.text}
                      </button>
                    ))}
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}

        {isSimulatingCheck && (
          <div className="flex items-center gap-2 text-xs text-sky-400 bg-sky-950/40 border border-sky-800/40 px-3 py-2 rounded-xl w-fit animate-pulse">
            <Radio className="w-3.5 h-3.5 animate-spin" />
            <span>Scanning active links via aiohttp...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Command Pill Shortcuts */}
      <div className="bg-slate-950/80 px-4 py-2 border-t border-slate-800/60 flex items-center gap-2 overflow-x-auto text-xs no-scrollbar">
        <span className="text-slate-500 text-[11px] font-semibold tracking-wider uppercase shrink-0">
          Commands:
        </span>
        {[
          { cmd: '/start', label: '🚀 Start' },
          { cmd: '/add', label: '➕ Add Link' },
          { cmd: '/list', label: '📋 List' },
          { cmd: '/remove', label: '🗑️ Remove' },
          { cmd: '/tools', label: '🛠️ Tools' },
          { cmd: '/cancel', label: '❌ Cancel' },
        ].map((item) => (
          <button
            key={item.cmd}
            onClick={() => handleCommand(item.cmd)}
            className="shrink-0 px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white rounded-md border border-slate-700/60 transition cursor-pointer font-mono text-[11px]"
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Input Message Form */}
      <div className="p-3 bg-slate-950 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Paste Facebook link(s) or type /start, /add, /list..."
          className="flex-1 bg-slate-900 border border-slate-800 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder-slate-500 outline-none transition"
        />
        <button
          onClick={handleSend}
          disabled={!inputValue.trim()}
          className="bg-sky-600 hover:bg-sky-500 disabled:opacity-40 disabled:hover:bg-sky-600 text-white p-2.5 rounded-xl transition cursor-pointer flex items-center justify-center shrink-0 shadow-md"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
