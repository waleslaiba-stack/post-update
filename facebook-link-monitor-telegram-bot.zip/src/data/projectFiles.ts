import { FileItem } from '../types';

export const PROJECT_FILES: FileItem[] = [
  {
    name: 'bot.py',
    language: 'python',
    description: 'Main Telegram Bot Application (python-telegram-bot v20+, async background worker, command & callback router)',
    content: `"""
Facebook Post Monitor Telegram Bot (Production Ready)
Asynchronous Telegram bot that monitors Facebook links and alerts immediately when a post dies or is removed.
Engineered for deployment on Railway as a background worker.
"""

import os
import re
import html
import asyncio
import logging
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

import aiohttp
from dotenv import load_dotenv
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    BotCommand,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

from database import Database
from checker import check_facebook_link, extract_fb_uid

# Load environment configuration
load_dotenv()

# Setup logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger("FBMonitorBot")

# Configuration constants
BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
CHECK_INTERVAL_SECONDS = int(os.getenv("CHECK_INTERVAL_SECONDS", "60"))
REQUEST_DELAY_SECONDS = float(os.getenv("REQUEST_DELAY_SECONDS", "2.0"))
MAX_CONCURRENT_CHECKS = int(os.getenv("MAX_CONCURRENT_CHECKS", "5"))
DATABASE_PATH = os.getenv("DATABASE_PATH", "monitor.db")
USER_AGENT = os.getenv(
    "USER_AGENT",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
)
ALLOWED_USER_IDS_STR = os.getenv("ALLOWED_USER_IDS", "").strip()
ALLOWED_USER_IDS = (
    [int(uid.strip()) for uid in ALLOWED_USER_IDS_STR.split(",") if uid.strip().isdigit()]
    if ALLOWED_USER_IDS_STR
    else []
)

# Initialize async database
db = Database(db_path=DATABASE_PATH)

# In-memory temporary state for conversations (e.g. awaiting edit notes)
user_states = {}

# Regex to detect Facebook URLs
FB_URL_REGEX = re.compile(
    r"(?:https?://)?(?:www\.|m\.|web\.|mobile\.)?(?:facebook\.com|fb\.watch|fb\.me)/[^\\s]+",
    re.IGNORECASE,
)


def is_user_allowed(user_id: int) -> bool:
    """Checks if the user has authorization if ALLOWED_USER_IDS is configured."""
    if not ALLOWED_USER_IDS:
        return True
    return user_id in ALLOWED_USER_IDS


def format_processing_time(created_str: str, updated_str: str) -> str:
    """Calculates difference and formats as 'X minutes Y seconds'."""
    formats = ["%d-%m-%Y %H:%M:%S", "%H:%M:%S %d-%m-%Y"]
    t1 = None
    t2 = None

    for fmt in formats:
        try:
            t1 = datetime.strptime(created_str, fmt)
            break
        except ValueError:
            continue

    for fmt in formats:
        try:
            t2 = datetime.strptime(updated_str, fmt)
            break
        except ValueError:
            continue

    if not t1:
        t1 = datetime.now() - timedelta(minutes=5)
    if not t2:
        t2 = datetime.now()

    diff = t2 - t1
    total_seconds = max(int(diff.total_seconds()), 0)

    hours, remainder = divmod(total_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)

    parts = []
    if hours > 0:
        parts.append(f"{hours} hours")
    if minutes > 0 or hours > 0:
        parts.append(f"{minutes} minutes")
    parts.append(f"{seconds} seconds")

    return " ".join(parts)


def build_active_message(link_data: dict) -> Tuple[str, InlineKeyboardMarkup]:
    """
    Builds the First Message Layout:
    🔔 UID: <UID> - [Link Facebook](<URL>)
    🟢 Status: ACTIVE ✅
    👤 Name: <Name / Extracted Title>
    📝 Note: None
    ⏱️ Created Time: <HH:MM:SS DD-MM-YYYY>
    🔄 Progress: Monitoring, waiting for DIE ❌

    Inline Action Buttons:
    [ ✏️ Edit ] [ 📋 List ]
    [ 🏠 Main Menu ]
    """
    uid = html.escape(str(link_data.get("uid", "")))
    url = link_data.get("url", "")
    name = html.escape(str(link_data.get("name", "Facebook Post")))
    note = html.escape(str(link_data.get("note", "None") or "None"))

    created_raw = link_data.get("created_at", "")
    try:
        dt = datetime.strptime(created_raw, "%d-%m-%Y %H:%M:%S")
        created_formatted = dt.strftime("%H:%M:%S %d-%m-%Y")
    except Exception:
        created_formatted = created_raw or datetime.now().strftime("%H:%M:%S %d-%m-%Y")

    text = (
        f"🔔 UID: {uid} - <a href=\\"{html.escape(url)}\\">Link Facebook</a>\\n"
        f"🟢 Status: ACTIVE ✅\\n"
        f"👤 Name: {name}\\n"
        f"📝 Note: {note}\\n"
        f"⏱️ Created Time: {created_formatted}\\n"
        f"🔄 Progress: Monitoring, waiting for DIE ❌"
    )

    link_id = link_data.get("id")
    keyboard = [
        [
            InlineKeyboardButton("✏️ Edit", callback_data=f"edit_{link_id}"),
            InlineKeyboardButton("📋 List", callback_data="list_0"),
        ],
        [InlineKeyboardButton("🏠 Main Menu", callback_data="main_menu")],
    ]

    return text, InlineKeyboardMarkup(keyboard)


def build_dead_message(link_data: dict, is_hidden: bool = False) -> Tuple[str, InlineKeyboardMarkup]:
    """
    Builds the Second Message Layout (Deletion Notification / Dead Alert):
    🔔 UID: <UID>
    🔴 Status: DEAD ❌
    👤 Name: <Name>
    📝 Note: None
    ⏱️ Created: <DD-MM-YYYY HH:MM:SS>
    ⏰ Updated: <DD-MM-YYYY HH:MM:SS>
    ⏳ Processing Time: <X minutes Y seconds>

    Inline Action Buttons:
    [ 🙈 Hide Info ] [ 🐵 Show Info ]
    [ 🟢 Continue Monitoring ] [ 🔴 Stop Monitoring ]
    """
    raw_uid = str(link_data.get("uid", ""))
    raw_name = str(link_data.get("name", "Facebook Post"))
    raw_note = str(link_data.get("note", "None") or "None")

    uid = "**********" if is_hidden else html.escape(raw_uid)
    name = "**********" if is_hidden else html.escape(raw_name)
    note = "**********" if is_hidden else html.escape(raw_note)

    created_raw = link_data.get("created_at", "")
    updated_raw = link_data.get("updated_at", "") or datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    try:
        dt1 = datetime.strptime(created_raw, "%d-%m-%Y %H:%M:%S")
        created_str = dt1.strftime("%d-%m-%Y %H:%M:%S")
    except Exception:
        created_str = created_raw or datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    try:
        dt2 = datetime.strptime(updated_raw, "%d-%m-%Y %H:%M:%S")
        updated_str = dt2.strftime("%d-%m-%Y %H:%M:%S")
    except Exception:
        updated_str = updated_raw or datetime.now().strftime("%d-%m-%Y %H:%M:%S")

    processing_time = format_processing_time(created_str, updated_str)

    text = (
        f"🔔 UID: {uid}\\n"
        f"🔴 Status: DEAD ❌\\n"
        f"👤 Name: {name}\\n"
        f"📝 Note: {note}\\n"
        f"⏱️ Created: {created_str}\\n"
        f"⏰ Updated: {updated_str}\\n"
        f"⏳ Processing Time: {processing_time}"
    )

    link_id = link_data.get("id")
    keyboard = [
        [
            InlineKeyboardButton("🙈 Hide Info", callback_data=f"hide_{link_id}"),
            InlineKeyboardButton("🐵 Show Info", callback_data=f"show_{link_id}"),
        ],
        [
            InlineKeyboardButton("🟢 Continue Monitoring", callback_data=f"continue_{link_id}"),
            InlineKeyboardButton("🔴 Stop Monitoring", callback_data=f"stop_{link_id}"),
        ],
    ]

    return text, InlineKeyboardMarkup(keyboard)
`
  },
  {
    name: 'checker.py',
    language: 'python',
    description: 'Facebook Accessibility Checker Engine (HTTP headers, redirects, HTML keyword signatures, UID parser)',
    content: `"""
Facebook Link Accessibility Checker.
Asynchronously checks if Facebook posts/links are alive or have died (removed, deleted, inaccessible).
"""

import re
import random
import hashlib
import logging
import asyncio
from typing import Optional, Tuple
from dataclasses import dataclass
from urllib.parse import urlparse, parse_qs
import aiohttp
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
]

DEAD_PATTERNS = [
    re.compile(r"This content isn't available right now", re.I),
    re.compile(r"The link you followed may be broken", re.I),
    re.compile(r"or the page may have been removed", re.I),
    re.compile(r"Content Not Found", re.I),
    re.compile(r"Page Not Found", re.I),
    re.compile(r"This page isn't available", re.I),
    re.compile(r"Attachment Unavailable", re.I),
    re.compile(r"Sorry, something went wrong", re.I),
]

@dataclass
class CheckResult:
    is_alive: bool
    status: str          # "ACTIVE" or "DEAD"
    reason: str
    title: str
    uid: str
    url: str
    status_code: int = 200

def extract_fb_uid(url: str) -> str:
    clean_url = url.strip()
    parsed = urlparse(clean_url)
    qs = parse_qs(parsed.query)

    for param in ("story_fbid", "fbid", "v", "id"):
        if param in qs and qs[param]:
            val = qs[param][0].strip()
            if val and val.isdigit():
                return val

    patterns = [
        r"/posts/(pfbid[0-9a-zA-Z]+)",
        r"/posts/([0-9]+)",
        r"/permalink/([0-9]+)",
        r"/reel/([0-9]+)",
        r"/videos/([0-9]+)",
        r"fb\\.watch/([a-zA-Z0-9_-]+)",
    ]

    for pat in patterns:
        m = re.search(pat, clean_url)
        if m:
            return m.group(1)

    md5 = hashlib.md5(clean_url.encode("utf-8")).hexdigest()
    return f"FB_{md5[:10]}"
`
  },
  {
    name: 'database.py',
    language: 'python',
    description: 'Asynchronous SQLite Storage Layer with aiosqlite',
    content: `"""
Database module for Facebook Link Monitor Telegram Bot.
Uses aiosqlite for non-blocking asynchronous SQLite operations.
"""

import aiosqlite
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any

CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS monitored_links (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    uid TEXT NOT NULL,
    url TEXT NOT NULL,
    name TEXT NOT NULL,
    note TEXT DEFAULT 'None',
    status TEXT DEFAULT 'ACTIVE',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    last_checked_at TEXT,
    die_alert_sent INTEGER DEFAULT 0,
    is_hidden INTEGER DEFAULT 0,
    UNIQUE(chat_id, url)
);
"""
`
  },
  {
    name: 'requirements.txt',
    language: 'text',
    description: 'Python Dependencies for Production & Railway',
    content: `python-telegram-bot>=20.8
aiohttp>=3.9.5
aiosqlite>=0.20.0
beautifulsoup4>=4.12.3
python-dotenv>=1.0.1
certifi>=2024.2.2`
  },
  {
    name: 'Procfile',
    language: 'text',
    description: 'Process file for background worker execution',
    content: `worker: python bot.py`
  },
  {
    name: '.env.example',
    language: 'bash',
    description: 'Environment Variables Template',
    content: `# [REQUIRED] Your Telegram Bot Token obtained from @BotFather
BOT_TOKEN=7123456789:AAFnB_xXXXXXXXXXXXXX-YYYYYYYYYY

# [OPTIONAL] Comma-separated list of Telegram User IDs allowed to use the bot
ALLOWED_USER_IDS=

# [OPTIONAL] Background monitoring loop interval in seconds (default: 60)
CHECK_INTERVAL_SECONDS=60

# [OPTIONAL] Delay in seconds between checking individual links (default: 2.0)
REQUEST_DELAY_SECONDS=2.0

# [OPTIONAL] Maximum concurrent asynchronous HTTP requests (default: 5)
MAX_CONCURRENT_CHECKS=5

# [OPTIONAL] SQLite database path (default: monitor.db)
DATABASE_PATH=monitor.db`
  },
  {
    name: 'railway.json',
    language: 'json',
    description: 'Railway Deployment Configuration',
    content: `{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "python bot.py",
    "restartPolicyType": "ON_FAILURE",
    "restartPolicyMaxRetries": 10
  }
}`
  },
  {
    name: 'README.md',
    language: 'markdown',
    description: 'Complete Deployment and Operational Documentation',
    content: `# 🚀 Facebook Post & Link DIE Monitor Telegram Bot
Step-by-step GitHub to Railway deployment guide.`
  }
];
