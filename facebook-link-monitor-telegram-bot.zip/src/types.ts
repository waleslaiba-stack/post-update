export interface MonitoredLink {
  id: number;
  uid: string;
  url: string;
  name: string;
  note: string;
  status: 'ACTIVE' | 'DEAD' | 'STOPPED';
  createdAt: string;     // format: 'DD-MM-YYYY HH:MM:SS'
  updatedAt: string;     // format: 'DD-MM-YYYY HH:MM:SS'
  lastCheckedAt?: string;
  isDeadAlertSent: boolean;
  isHidden: boolean;
}

export interface TelegramButton {
  text: string;
  callbackData: string;
  action?: () => void;
}

export interface TelegramMessage {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  html?: string;
  timestamp: string;
  buttons?: TelegramButton[][];
  linkId?: number;
  isDeadAlert?: boolean;
}

export interface FileItem {
  name: string;
  language: string;
  description: string;
  content: string;
}
